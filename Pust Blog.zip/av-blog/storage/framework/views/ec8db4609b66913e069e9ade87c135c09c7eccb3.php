<?php $__env->startSection('content'); ?>
<div class="container">

    <div class="row">
        <div class="col-md-8 col-md-offset-0">
            <div class="panel panel-default">
                <div class="panel-body">
                <?php echo Form::open(); ?>

            	<div class="panel panel-default">

                    <div class="panel-body">
                        <div class="form-group">
                        	 <label>Heading</label>
                        	<textarea class="form-control" name="status-heading-text"  id="status-heading-text"></textarea>
                            <label> Write Something</label>
                            <textarea class="form-control" name="status-text"  id="status-text"></textarea>   
                        </div>

                    </div>
                <div class="panel-footer clearfix">
      			<div class= "form-group">
						<select class="selectpicker show-tick" name="type" id="type" data-size="4">

    								<option>Education</option>
    								<option>Sports</option>
                                  	<option>Campus</option>
                                  	<option>News</option>
                          </select>
                 </div>
                 	<button class="btn btn-info pull-right btn-sm">Post</button>
                 </div>
            	
            	<?php echo Form::close(); ?>

            	</div>
            	 <?php $__currentLoopData = $top_5_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           
                <?php echo view('layouts.user_status_layout',[
                    'status' => $status,
                     'user' => \App\Eloquent\User::find($status->user_id),
                     'comments' => \App\Eloquent\Comment::where('status_id',$status->id)->orderBy('id','DESC')->get() 
                      ]); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            	</div>           	
        </div>
    </div>
    <?php echo e($top_5_posts->links()); ?>

    <div class="col-sm-4 col-sm-offset-0">
    	<div class="panel-body">
    		<img alt="pust.jpg" src="<?php echo e(asset('frontEnd/img/pust.jpg')); ?>" height=250px width=450px>
    	</div>
    	 
    	 	<div class="panel panel-warning">
    	 		<div class="panel-body">
    				<h3><b>Catagories</b></h3>
    				<li><a href='/catagory/Sports/'>Sports</a></li>
    				<li><a href='/catagory/Education/'>Education</a></li>
    				<li><a href='/catagory/Campus/'>Campus</a></li>
    				<li><a href='/catagory/News/'>News</a></li>
    			</div>
    		</div>
	
    </div>
    
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>