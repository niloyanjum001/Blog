<?php $__env->startSection('admin_content'); ?>
<div class="container">
	
    <div class="row">
        <div class="col-md-12 col-md-offset-0">
            <div class="panel panel-default">
                <div class="panel-body">
                
            	<div class="panel panel-default">
<!-- <form  action="<?php echo e(url('/admin/dashboard_')); ?>" method="post" enctype="multipart/form-data"> -->


<!-- </form> -->
            	 <?php $__currentLoopData = $top_15_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            	 
            	 <div class="panel panel-default">
                	 	<div class="panel-heading ">
        					<div class="panel-title text-left">				
             					<b><?php echo e($status->status_heading_text); ?></b>
        					</div>
        					<div class="panel-title text-right">				
             					<i><span><?php echo e($status->type); ?></span></i>
        					</div>
        				</div>
                       <div class="panel-body">
                         <div class="row">
                           <div class="col-md-11">
                               <p><?php echo e($status->status_text); ?></p>
                               <i><?php echo e($status->created_at->diffForHumans()); ?></i>
                           </div>
                           <div class="col-md-8">
                              <hr>
                              <ul class="list-unstyled list-inline">
                                <li>
                                     <?php echo Form::open(); ?>

                                     <?php echo Form::hidden('approve',$status->id); ?>

                                        <input type="submit" name="submit" value="Approve" id="submit" class="btn btn-success btn-lg">
                                     <?php echo Form::close(); ?>

                                     <?php echo Form::open(); ?>

                                     <?php echo Form::hidden('dismiss',$status->id); ?>

                                        <input type="submit" name="submit" value="Dismiss" id="submit" class="btn btn-danger btn-lg">
                                     <?php echo Form::close(); ?>

                               		
                                </li>
                             </ul>
                           </div>
                          </div>
                       </div>
                </div>
                 
            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            	</div>           
            	
        </div>
          
    </div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>