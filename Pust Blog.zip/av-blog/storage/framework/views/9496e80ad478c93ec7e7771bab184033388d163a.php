<?php $__env->startSection('admin_content'); ?>
<div class="container">
	
    <div class="row">
        <div class="col-md-12 col-md-offset-0">
            <div class="panel panel-default">
                <div class="panel-body">



            	 <?php $__currentLoopData = $top_15_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            	     <?php echo view('layouts.user_status_layout',[
                    'status' => $status,
                     'user' => \App\Eloquent\User::find($status->user_id),
                     'comments' => \App\Eloquent\Comment::where('status_id',$status->id)->orderBy('id','DESC')->get() 
                      ]); ?>

            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            	</div>           	
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>