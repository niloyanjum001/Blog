

    
  	<div class="panel panel-default">
    <div class="panel-heading"><b><?php echo e($status->status_heading_text); ?> </b></div>
       <div class="panel-body">
         <div class="row">
           <div class="col-md-11">
               <p><?php echo e($status->status_text); ?></p>
               <p>-<?php echo e($user->name); ?></p>
               <i><?php echo e($status->created_at->diffForHumans()); ?></i>
           </div>
           <div class="col-md-8">
              <hr>
              <ul class="list-unstyled list-inline">
                <li>
                   <button  class="btn btn-xs btn-info"  type="button" data-toggle="collapse" data-target="#view-comments-<?php echo e($status->id); ?>" aria-expanded="false" aria-controls="view-comments-<?php echo e($status->id); ?>">View & Comment</button>
               		<span><?php echo e($status->type); ?></span>
                </li>
             </ul>
           </div>
          </div>
       </div>

<div class="panel-footer clearfix">
    <?php echo Form::open(); ?>

    <?php echo Form::hidden('post_comment',$status->id); ?>

     
        <div class="form-group">
        <div class="input-group">
            <input type="text" class="form-control" name="comment-text" id="comment-text" placeholder="Post a comment">
            <span class="input-group-btn">
                 <button class="btn btn-default" type="submit">Go!</button>
            </span>
              
         </div>
    </div>
    <?php echo Form::close(); ?>



    <div class="collapse" id="view-comments-<?php echo e($status->id); ?>"> 

        <?php if($comments->first()): ?>
            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                
                    <div class="row">

                        <div class="col-md-10">
                            <ul class="list-unstyled list-inline ">
                                <li>
                                    <a href=""><?php echo e(App\Eloquent\User::find($comment->user_id)->name); ?></a>
                                </li>
                                <li>
                                    <i>commented <?php echo e($comment->created_at->diffForHumans()); ?></i>
                                </li>
                                
                            </ul>
                            
                                <p><?php echo e($comment->comment_text); ?></p>
                        </div>
                        
                    </div>
               

            

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <p>This status contains no comments</p>
        <?php endif; ?>

    </div>

</div>
</div>

