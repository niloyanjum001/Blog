<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::group(['middleware' => 'admin_guest'], function() {
    Route::get('/admin_login', 'Admin\LoginController@showLoginForm')->name('admin-login');
    Route::post('/admin_login', 'Admin\LoginController@login');
    
});
Route::group(['middleware' => 'admin_auth'], function(){
        Route::any('/catagory/admin/Sports/', 'AdminController@cat_sports');
        Route::any('/catagory/admin/Education/', 'AdminController@cat_edu');
        Route::any('/catagory/admin/Campus/', 'AdminController@cat_campus');
        Route::any('/catagory/admin/News/', 'AdminController@cat_news');
        Route::post('/admin_logout', 'Admin\LoginController@logout');
        Route::get('/admin_home','AdminController@index');
        Route::any('/admin/dashboard', 'AdminController@dashboard')->name('dashboard');
        Route::get('/admin/dashboard-approved', 'AdminController@dashboard_post');
    });

Auth::routes();

Route::any('/', 'HomeController@index')->name('home');
Route::any('/catagory/Sports/', 'HomeController@cat_sports');
Route::any('/catagory/Education/', 'HomeController@cat_edu');
Route::any('/catagory/Campus/', 'HomeController@cat_campus');
Route::any('/catagory/News/', 'HomeController@cat_news');
Route::get('/dashboard', 'HomeController@dashboard')->name('dashboard');
Route::get('/dashboard-approved', 'HomeController@dashboard_post');



